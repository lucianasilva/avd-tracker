# AVD Roadmap Tracker

Accelerating Value Delivery — Implementation Roadmap Tracker  
Liferay Product Delivery Department

---

## What this is

A lightweight web app deployed on GitHub Pages that lets EPMs track adoption of the 7 AVD actions (A1–A7), run bi-weekly check-ins with adoption scores, and export progress snapshots. Access is restricted to a fixed list of GitHub usernames via OAuth.

---

## One-time setup (≈ 20 minutes)

### Step 1 — Create the repository

1. Go to [github.com/new](https://github.com/new)
2. Repository name: `avd-tracker`
3. Set visibility to **Private**
4. Click **Create repository**

### Step 2 — Enable GitHub Pages

1. Go to **Settings → Pages**
2. Under **Source**, select **GitHub Actions**
3. Save

### Step 3 — Create a GitHub OAuth App

1. Go to [github.com/settings/developers](https://github.com/settings/developers)
2. Click **New OAuth App**
3. Fill in:
   - **Application name:** `AVD Tracker`
   - **Homepage URL:** `https://YOUR-USERNAME.github.io/avd-tracker`
   - **Authorization callback URL:** `https://YOUR-USERNAME.github.io/avd-tracker`
4. Click **Register application**
5. Copy the **Client ID** — you will need it in Step 5
6. Click **Generate a new client secret** — copy and save it securely

### Step 4 — Deploy Gatekeeper (OAuth proxy)

GitHub OAuth requires a server-side step to exchange the code for a token (to keep your Client Secret safe). The standard solution is [Gatekeeper](https://github.com/prose/gatekeeper), a tiny Node.js proxy.

**Easiest option: deploy to Render (free tier)**

1. Go to [render.com](https://render.com) and create a free account
2. Click **New → Web Service**
3. Connect it to this repo: `https://github.com/prose/gatekeeper`
4. Set these environment variables:
   - `GITHUB_CLIENT_ID` = your Client ID from Step 3
   - `GITHUB_CLIENT_SECRET` = your Client Secret from Step 3
   - `HOST` = `YOUR-USERNAME.github.io`
5. Deploy — Render gives you a URL like `https://avd-tracker-gatekeeper.onrender.com`
6. Copy that URL — you need it in Step 5

> **Alternative:** Deploy to Railway, Fly.io, or any Node.js host. Gatekeeper is ~50 lines of code.

### Step 5 — Configure the app

Open `docs/index.html` and update the three config values at the top of the `<script>` block:

```js
const GITHUB_CLIENT_ID = 'YOUR_GITHUB_CLIENT_ID';  // from Step 3
const GATEKEEPER_URL   = 'YOUR_GATEKEEPER_URL';     // from Step 4
const ALLOWED_USERS    = [                          // lowercase GitHub usernames
  'your-github-username',
  'epm-headless-github',
  'epm-fi-github',
  'epm-bpm-github',
  'epm-cm-github',
  'epm-cloud-github',
  'tl-headless-github',
  'tl-fi-github',
];
```

### Step 6 — Push to GitHub and deploy

```bash
git init
git add .
git commit -m "Initial deploy"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/avd-tracker.git
git push -u origin main
```

GitHub Actions will deploy automatically. The app will be live at:  
`https://YOUR-USERNAME.github.io/avd-tracker`

---

## Adding or removing users

Edit the `ALLOWED_USERS` array in `docs/index.html`, commit, and push.  
The deploy workflow runs automatically and the new list is live in ~60 seconds.

```js
const ALLOWED_USERS = [
  'existing-user',
  'new-epm-username',  // added
  // 'removed-user',   // removed
];
```

---

## How data works

| What | Where |
|---|---|
| Roadmap progress, check-in scores, history | Browser `localStorage` on each EPM's machine |
| Storage key | `avd-data-{github-username}-{team-name}` |
| Sharing progress | EPM clicks **Export JSON** → sends file to Program Manager |
| Program Manager imports | Opens the app, goes to Setup, clicks **Import JSON** |
| Audit trail | Commit exported JSON files to this repo under `/snapshots/{team}/` |

### Recommended bi-weekly workflow

1. EPM opens the app, goes to **Bi-weekly Check-in**
2. Updates adoption scores (1–5) and notes per action
3. Clicks **Get coaching prompts** to prepare the sync agenda
4. Runs the bi-weekly sync with TL
5. Clicks **Save check-in** — entry is added to History
6. Clicks **Export JSON** — sends file to Program Manager via Slack

---

## Snapshot convention (optional)

To keep a shared history in the repo, create a `/snapshots` folder and commit JSON exports after each check-in:

```
snapshots/
  bpm/
    avd-bpm-2026-02-10.json
    avd-bpm-2026-02-24.json
  cm/
    avd-cm-2026-02-10.json
  cloud/
    avd-cloud-2026-02-10.json
```

---

## Local development

No build step needed. Open `docs/index.html` directly in your browser.  
Note: OAuth will not work locally (GitHub redirects to the Pages URL). For local testing, temporarily bypass the auth check in `checkExistingSession()`.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| "Access denied" on sign-in | Add your GitHub username (lowercase) to `ALLOWED_USERS` in `index.html` |
| Blank page after OAuth redirect | Check that `GATEKEEPER_URL` is set correctly and the Gatekeeper service is running |
| Data not persisting | Check browser settings — some browsers block `localStorage` in private/incognito mode |
| Deploy not triggering | Check **Actions** tab in GitHub — verify the workflow has `pages: write` permission |

---

## Security notes

- The Client Secret is **never** in the frontend code — it lives only in Gatekeeper's environment variables
- `ALLOWED_USERS` is a frontend allowlist — sufficient for internal tooling with low attack surface
- All data stays in the user's browser — nothing is sent to any server except the GitHub OAuth flow
- The repository is private — the source code is not publicly visible
